Project 3
Guillermo Rivera
grrivera@wpi.edu

To run:
Project_3.py

When running, the program will ask you for file name to test, must include ".txt" extension at end of name. Make sure input files are in same folder where the project is being run from.

Using: 
Exhaustive Search
Dynamic Programming
Greed Algorithm

