# arduino-midi-lights
This is a project to control a number of lights according to a song in correct sync with the music. It can be used to control stage lights and fog machines with a computer and achieve wonderful synchronization for performances on stage which is not possible with manual lighting control consoles.

FILE MISSING:
The .wav file for the song can be donwloaded here: www.dropbox.com/s/jj7p7djc437w2g5/Carol%20of%20the%20bells.wav?dl=1

View the tutorial at https://techmusician.wordpress.com/2017/01/01/the-arduino-lights-project/

Story behind this project https://techmusician.wordpress.com/2016/12/24/the-christmas-lights-project/
